﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Close : MonoBehaviour
{
    public void doExitGame()
    {
        Application.Quit();
    }
}
